<?php
mysql_connect('localhost','root','');
mysql_select_db('station') or die('Cant connect to db');
