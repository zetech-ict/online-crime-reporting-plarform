<?php
session_start();
require('connect.php');
include 'functions/core.php';

$errors = array();

/*
if(logged_in()=== true){
    $session_user_id = $_SESSION['user_id'];
    $user_data = user_data($session_user_id,'ID_Customer','First_Name','Last_Name');
 }
 * *
 */
?>