<?php
	session_start();
	require 'php/functions/general.php';
	require 'php/classes/db.php';
?>